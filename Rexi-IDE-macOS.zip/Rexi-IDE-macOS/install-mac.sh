#!/usr/bin/env bash
# Rexi for OpenCode — macOS installer (Apple silicon and Intel)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.config/opencode"
echo "▸ Rexi for OpenCode — installing to $DEST"
if ! command -v opencode >/dev/null 2>&1; then
  echo "▸ Installing OpenCode (open source, MIT)…"
  if command -v brew >/dev/null 2>&1; then brew install opencode || npm install -g opencode-ai
  elif command -v npm >/dev/null 2>&1; then npm install -g opencode-ai
  else curl -fsSL https://opencode.ai/install | bash; fi
fi
command -v python3 >/dev/null 2>&1 || { echo "✗ python3 is required for the Rexi tools (install Xcode command line tools: xcode-select --install)"; exit 1; }
mkdir -p "$DEST/agents" "$DEST/themes" "$HOME/.rexi"
cp -R "$HERE/mcp" "$HOME/.rexi/" && cp "$HERE/REXI.md" "$HOME/.rexi/"
cp "$HERE/.opencode/agents/"*.md "$DEST/agents/" && cp "$HERE/.opencode/themes/rexi.json" "$DEST/themes/"
sed "s#{env:REXI_HOME}#$HOME/.rexi#; s#\"REXI.md\"#\"$HOME/.rexi/REXI.md\"#" "$HERE/opencode.json" > "$DEST/opencode.json.rexi"
if [ -f "$DEST/opencode.json" ]; then echo "▸ Kept your existing opencode.json; Rexi config saved as opencode.json.rexi — merge the mcp/agent/command blocks."; else mv "$DEST/opencode.json.rexi" "$DEST/opencode.json"; fi
[ -f "$DEST/tui.json" ] || cp "$HERE/tui.json" "$DEST/tui.json"
read -r -p "Rexi server URL [http://localhost:8000]: " URL || true; URL="${URL:-http://localhost:8000}"
[ -f "$DEST/opencode.json" ] && sed -i '' "s#http://localhost:8000#$URL#" "$DEST/opencode.json" || true
echo "✓ Done. Open a project and run:  opencode   then try  /rexi-fixes"
