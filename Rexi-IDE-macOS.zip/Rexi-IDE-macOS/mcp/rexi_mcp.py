#!/usr/bin/env python3
"""Rexi MCP server — lets OpenCode (or any MCP client) work with Rexi.

Pure standard library, stdio transport (JSON-RPC 2.0, one message per line).
Talks to the Rexi backend over HTTP; set REXI_URL (default http://localhost:8000)
and, for a shared server, REXI_TOKEN (sent as a Bearer token).

Tools
  rexi_fixes           list Autopilot fixes with their all-agent confidence
  rexi_fix_detail      every agent's score, reason and "what would raise it" for one fix
  rexi_reject_fix      reject the latest attempt with written feedback
  rexi_rerun_fix       rerun a fix — every agent re-scores it with the feedback
  rexi_approve_fix     approve a fix (a person; below the floor needs a reason)
  rexi_governance      KPIs, autonomy policy and decision-log integrity
  rexi_redact          show exactly what a model would see after redaction
  rexi_pause_agents    the kill switch: pause or resume every agent action
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request

BASE = os.environ.get("REXI_URL", "http://localhost:8000").rstrip("/")
TOKEN = os.environ.get("REXI_TOKEN", "")
ACTOR = os.environ.get("REXI_USER") or os.environ.get("USER") or os.environ.get("USERNAME") or "developer"
VERSION = "1.0.0"


def call(method: str, path: str, body: dict | None = None) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "application/json", "Accept": "application/json"})
    if TOKEN:
        req.add_header("Authorization", "Bearer " + TOKEN)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read()).get("detail")
        except Exception:
            detail = e.reason
        raise RuntimeError(f"Rexi said {e.code}: {detail}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Can't reach Rexi at {BASE} ({e.reason}). Is the backend running? Set REXI_URL if it runs elsewhere.")


def fmt_fix(f: dict) -> str:
    a = f.get("latest") or f["attempts"][-1]
    hist = " → ".join(f"{x['confidence']}%" for x in f["attempts"])
    return (f"{f['key']} · {f.get('title','')}\n  confidence {a['confidence']}% ({a['verdict']}), attempt {a['attempt']}, "
            f"status {a['status']}; lowest: {a['lowest']['agent']} {a['lowest']['confidence']}%; history {hist}")


def t_fixes(_):
    r = call("GET", "/api/governance/fixes")
    s = r["summary"]
    head = (f"{s['fixes']} Autopilot fix(es) · average confidence {s['average_confidence']}% · "
            f"release floor {r['floor']}% · {s['rejections']} rejection(s) with feedback")
    return head + "\n\n" + "\n".join(fmt_fix(f) for f in r["fixes"]) if r["fixes"] else head


def t_detail(a):
    r = call("GET", "/api/governance/fixes")
    f = next((x for x in r["fixes"] if x["key"] == a["key"]), None)
    if not f:
        raise RuntimeError(f"No fix called {a['key']}")
    lat = f["latest"]
    rows = "\n".join(f"  {g['confidence']:>3}%  {g['name']}: {g['why']} (to raise: {g['to_raise']})" for g in lat["agents"])
    fb = "\n".join(f"  💬 {x['by']} on attempt {x['attempt']}: {x['text']}" for x in f.get("feedback", []))
    return fmt_fix(f) + "\n\nAll agents:\n" + rows + (("\n\nFeedback:\n" + fb) if fb else "")


def t_reject(a):
    f = call("POST", f"/api/governance/fixes/{a['key']}/reject", {"actor": a.get("actor") or ACTOR, "feedback": a["feedback"]})
    return "Rejected. Feedback saved (personal data redacted) and sent to every agent on the rerun.\n" + fmt_fix(f)


def t_rerun(a):
    f = call("POST", f"/api/governance/fixes/{a['key']}/rerun", {"actor": a.get("actor") or ACTOR})
    return "Rerun complete — every agent re-scored the fix.\n" + fmt_fix(f)


def t_approve(a):
    f = call("POST", f"/api/governance/fixes/{a['key']}/approve",
             {"actor": a.get("actor") or ACTOR, "override_reason": a.get("override_reason", "")})
    return "Approved and logged. The production release still needs a named approver in Rexi.\n" + fmt_fix(f)


def t_gov(_):
    g = call("GET", "/api/governance")
    k, p = g["kpis"], g["policy"]
    auto = ", ".join(f"{u}: {m}" for u, m in p["autonomy"].items())
    return (f"Decision log: {'verified' if g['integrity']['ok'] else 'BROKEN'} ({g['integrity']['entries']} entries)\n"
            f"Agents paused: {p.get('paused', False)}\nAutonomy: {auto}\n"
            f"Routing accuracy: {k.get('routing_accuracy')} · needs triage: {k.get('needs_triage')} · "
            f"shadow agreement: {k.get('shadow_agreement')} · LLM tokens today: {k.get('llm_tokens_today')}")


def t_redact(a):
    r = call("POST", "/api/governance/redact", {"text": a["text"]})
    return r["text"] + ("\n\nRedacted: " + ", ".join(f"{k}×{v}" for k, v in r["counts"].items()) if r["counts"] else "")


def t_pause(a):
    r = call("POST", "/api/governance/kill-switch", {"actor": a.get("actor") or ACTOR, "on": bool(a["on"])})
    return "All agent actions paused." if r["paused"] else "Agents resumed."


S = lambda **p: {"type": "object", "properties": p, "required": [k for k, v in p.items() if not v.pop("_opt", False)]}
TOOLS = {
    "rexi_fixes": ("List Autopilot fixes with the all-agent confidence score, verdict and attempt history.", S(), t_fixes),
    "rexi_fix_detail": ("Show every agent's confidence, reason and what would raise it for one fix.",
                        S(key={"type": "string", "description": "Fix key, e.g. INC-2042"}), t_detail),
    "rexi_reject_fix": ("Reject the latest attempt of a fix with written feedback for the agents.",
                        S(key={"type": "string"}, feedback={"type": "string", "description": "What the agents should change"},
                          actor={"type": "string", "_opt": True}), t_reject),
    "rexi_rerun_fix": ("Rerun a rejected fix; every agent re-scores it using all feedback so far.",
                       S(key={"type": "string"}, actor={"type": "string", "_opt": True}), t_rerun),
    "rexi_approve_fix": ("Approve a fix as a named person. Below the confidence floor an override reason is required.",
                         S(key={"type": "string"}, actor={"type": "string", "_opt": True},
                           override_reason={"type": "string", "_opt": True}), t_approve),
    "rexi_governance": ("Show Rexi KPIs, autonomy per use case, kill-switch state and decision-log integrity.", S(), t_gov),
    "rexi_redact": ("Redact personal data and secrets from text, exactly as Rexi does before any model call.",
                    S(text={"type": "string"}), t_redact),
    "rexi_pause_agents": ("Kill switch: pause (on=true) or resume (on=false) every Rexi agent action.",
                          S(on={"type": "boolean"}, actor={"type": "string", "_opt": True}), t_pause),
}


def send(msg: dict) -> None:
    sys.stdout.write(json.dumps(msg) + "\n")
    sys.stdout.flush()


def handle(req: dict):
    m, rid = req.get("method"), req.get("id")
    if m == "initialize":
        return {"protocolVersion": req.get("params", {}).get("protocolVersion", "2024-11-05"),
                "capabilities": {"tools": {}}, "serverInfo": {"name": "rexi", "version": VERSION}}
    if m == "tools/list":
        return {"tools": [{"name": n, "description": d, "inputSchema": s} for n, (d, s, _) in TOOLS.items()]}
    if m == "tools/call":
        p = req.get("params", {})
        name, args = p.get("name"), p.get("arguments") or {}
        if name not in TOOLS:
            return {"content": [{"type": "text", "text": f"Unknown tool {name}"}], "isError": True}
        try:
            return {"content": [{"type": "text", "text": TOOLS[name][2](args)}]}
        except Exception as e:  # report to the model instead of crashing the server
            return {"content": [{"type": "text", "text": str(e)}], "isError": True}
    if m == "ping":
        return {}
    if rid is None:            # notifications (e.g. notifications/initialized) need no reply
        return None
    raise LookupError(m)


def main() -> None:
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
            continue
        try:
            res = handle(req)
            if req.get("id") is not None:
                send({"jsonrpc": "2.0", "id": req["id"], "result": res})
        except LookupError as e:
            send({"jsonrpc": "2.0", "id": req.get("id"), "error": {"code": -32601, "message": f"Method not found: {e}"}})


if __name__ == "__main__":
    main()
