# Working with Rexi

This project is delivered with **Rexi**, self-healing mobile delivery with people approving every release.

- Rexi agents propose fixes for crashes, emails, change requests and Jira defects. Every fix is scored by ten agents (triage, root cause, code, QA, regression, security, UX, product, release and the engineering manager).
- Use the `rexi_*` tools to read fixes, explain scores, reject with feedback, rerun and approve.
- Never approve a fix or pause agents without the developer's explicit yes. A production release always needs a named human in Rexi.
- Never paste personal data into prompts; use `rexi_redact` to check what a model would see.
