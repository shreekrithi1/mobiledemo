# Rexi for OpenCode — the Rexi IDE (macOS · Windows)

Rexi inside [OpenCode](https://opencode.ai), the open-source (MIT) AI coding agent that runs in your terminal, as a desktop app and in your IDE. Nothing is forked or patched — Rexi is added through OpenCode's own extension points, so OpenCode updates keep working.

## What you get
| | |
|---|---|
| **Rexi agent** (`rexi`) | Reads Autopilot fixes, explains every agent's confidence, drafts feedback, and helps you reject, rerun or approve — always asking before it decides anything. |
| **Rexi reviewer** (`@rexi-reviewer`) | Reviews your local diff the way Rexi's QA and Security agents will, before you push. |
| **Slash commands** | `/rexi-fixes` · `/rexi-why INC-2042` · `/rexi-reject INC-2043` · `/rexi-rerun INC-2043` · `/rexi-approve INC-2042` · `/rexi-status` |
| **Rexi tools (MCP)** | `rexi_fixes`, `rexi_fix_detail`, `rexi_reject_fix`, `rexi_rerun_fix`, `rexi_approve_fix`, `rexi_governance`, `rexi_redact`, `rexi_pause_agents` |
| **Rexi theme** | Teal, gold and night-navy, matching the Rexi app. |

## Install
**macOS** (Apple silicon or Intel): unzip, then in Terminal
```
cd Rexi-IDE-macOS && ./install-mac.sh
```
**Windows 10/11**: unzip, then in PowerShell
```
cd Rexi-IDE-Windows; powershell -ExecutionPolicy Bypass -File .\install-windows.ps1
```
The installer adds OpenCode if it's missing (Homebrew or npm on macOS, npm or Scoop on Windows), copies the Rexi agents, theme and tools to `~/.config/opencode` and `~/.rexi`, and asks for your Rexi server URL. It never overwrites an existing `opencode.json` — it saves `opencode.json.rexi` for you to merge.

**Requirements:** Python 3 (for the Rexi tools; standard library only) and a running Rexi backend.

## Use it
```
cd your-mobile-app
opencode
/rexi-fixes
```
Switch to the Rexi agent with **Tab**. Set `REXI_TOKEN` if your Rexi server requires a token.

## Safety
The Rexi agent never approves a fix or pauses agents without your explicit yes. Feedback is redacted before it is stored. Production releases still need a named approver in Rexi.
