import { api, settings, actor } from "./api.js";
const $ = id => document.getElementById(id), esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const col = v => v >= 85 ? "#16a34a" : v >= 70 ? "#d97706" : "#dc2626";
let tab = "fixes", open = {}, data = null, gov = null;

async function load() {
  const s = await settings(); $("srv").textContent = s.server.replace(/^https?:\/\//, ""); $("open").href = s.server.replace(/\/$/, "") + "/#trust";
  try { [data, gov] = await Promise.all([api("/api/governance/fixes"), api("/api/governance")]); }
  catch (e) { $("view").innerHTML = `<div class="err">${esc(e.message)}</div>`; $("kpis").innerHTML = ""; return; }
  const sm = data.summary, k = gov.kpis;
  $("kpis").innerHTML = [["Avg confidence", sm.average_confidence == null ? "—" : sm.average_confidence + "%"], ["Waiting", data.fixes.filter(f => f.latest.status !== "approved").length], ["Shadow agree", k.shadow_agreement == null ? "—" : Math.round(k.shadow_agreement * 100) + "%"]]
    .map(([a, b]) => `<div class="kpi"><small>${a}</small><b>${b}</b></div>`).join("");
  $("pause").classList.toggle("on", !!gov.policy.paused); $("pause").textContent = gov.policy.paused ? "▶ Resume agents" : "⏸ Pause agents";
  render();
}
function render() {
  if (tab === "fixes") {
    $("view").innerHTML = data.fixes.length ? data.fixes.map(f => { const a = f.latest, c = col(a.confidence);
      return `<div class="fix" style="--c:${c}"><div class="row"><span class="ring" style="--c:${c};--p:${a.confidence}"><i>${a.confidence}%</i></span>
        <div style="flex:1;min-width:0"><b>${esc(f.key)} · ${esc(f.title)}</b><small>Attempt ${a.attempt} · ${esc(a.verdict)} · ${esc(a.status)} · lowest ${esc(a.lowest.agent)} ${a.lowest.confidence}%</small></div></div>
        ${open[f.key] ? `<div class="agents">${a.agents.map(g => `<div class="ag" title="${esc(g.why)}"><span>${g.icon} ${esc(g.name)}</span><span class="bar"><i style="width:${g.confidence}%;background:${col(g.confidence)}"></i></span><b>${g.confidence}%</b></div>`).join("")}</div>` : ""}
        ${open[f.key] === "reject" ? `<textarea id="fb-${esc(f.key)}" rows="3" placeholder="What should the agents change?"></textarea>` : ""}
        <div class="acts"><button class="btn" data-a="why" data-k="${esc(f.key)}">${open[f.key] ? "Hide" : "All 10 agents"}</button>
        ${a.status === "approved" ? `<span class="chip ok">✓ Approved</span>` : a.status === "rejected" ? `<button class="btn pri" data-a="rerun" data-k="${esc(f.key)}">↻ Rerun</button>` :
          (open[f.key] === "reject" ? `<button class="btn pri" data-a="send" data-k="${esc(f.key)}">Send feedback</button>` : `<button class="btn" data-a="reject" data-k="${esc(f.key)}">Reject…</button><button class="btn pri" data-a="approve" data-k="${esc(f.key)}" data-c="${a.confidence}">Approve</button>`)}</div></div>`; }).join("")
      : `<div class="empty">No Autopilot fixes yet.</div>`;
  } else if (tab === "trust") {
    const p = gov.policy, k = gov.kpis;
    $("view").innerHTML = `<div class="list"><div><span>Decision log</span><span class="chip ${gov.integrity.ok ? "ok" : "no"}">${gov.integrity.ok ? "verified" : "broken"} · ${gov.integrity.entries}</span></div>
      <div><span>Release confidence floor</span><b>${p.min_release_confidence}%</b></div><div><span>Routing accuracy</span><b>${k.routing_accuracy == null ? "—" : Math.round(k.routing_accuracy * 100) + "%"}</b></div>
      <div><span>Needs triage</span><b>${k.needs_triage}</b></div><div><span>LLM tokens today</span><b>${(k.llm_tokens_today || 0).toLocaleString()} / ${p.llm_daily_token_cap.toLocaleString()}</b></div>
      ${Object.entries(p.autonomy).map(([u, m]) => `<div><span>${esc(u.replace("_", " "))}</span><span>${esc(m)}</span></div>`).join("")}</div>
      <div class="acts"><button class="btn" id="evi">⬇ Evidence pack</button></div>`;
    $("evi").onclick = async () => { const e = await api("/api/governance/evidence"); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(e, null, 2)], { type: "application/json" })); a.download = "rexi-evidence.json"; a.click(); };
  } else {
    $("view").innerHTML = `<small style="color:#64748b">Paste a crash log or email — this is exactly what a model would see.</small><textarea id="rd" rows="5">Crash for jane.doe@example.com on +1 (415) 555-0134</textarea><div class="acts"><button class="btn pri" id="rdgo">Redact</button></div><pre id="rdout" hidden></pre>`;
    chrome.storage.local.get("lastRedaction").then(({ lastRedaction: l }) => { if (l && l.text) { $("rdout").hidden = false; $("rdout").textContent = "From your last right-click:\n" + l.text; } });
    $("rdgo").onclick = async () => { const r = await api("/api/governance/redact", { method: "POST", body: { text: $("rd").value } }); $("rdout").hidden = false; $("rdout").textContent = r.text; };
  }
}
document.addEventListener("click", async e => {
  const b = e.target.closest("button[data-a]"); if (!b) return; const k = b.dataset.k, a = b.dataset.a;
  try {
    if (a === "why") { open[k] = open[k] ? 0 : "why"; return render(); }
    if (a === "reject") { open[k] = "reject"; render(); return $("fb-" + k)?.focus(); }
    b.disabled = true;
    if (a === "send") { const fb = $("fb-" + k).value.trim(); if (!fb) { b.disabled = false; return; } await api(`/api/governance/fixes/${k}/reject`, { method: "POST", body: { actor: await actor(), feedback: fb } }); open[k] = 0; }
    if (a === "rerun") await api(`/api/governance/fixes/${k}/rerun`, { method: "POST", body: { actor: await actor() } });
    if (a === "approve") { let reason = ""; if (+b.dataset.c < data.floor) { reason = prompt(`Below the ${data.floor}% floor — give an override reason (logged):`) || ""; if (!reason) { b.disabled = false; return; } }
      await api(`/api/governance/fixes/${k}/approve`, { method: "POST", body: { actor: await actor(), override_reason: reason } }); }
    chrome.runtime.sendMessage("refresh"); await load();
  } catch (err) { alert(err.message); b.disabled = false; }
});
document.querySelectorAll(".tabs button").forEach(b => b.onclick = () => { tab = b.dataset.t; document.querySelectorAll(".tabs button").forEach(x => x.classList.toggle("on", x === b)); render(); });
$("pause").onclick = async () => { const on = !gov.policy.paused; if (on && !confirm("Pause every Rexi agent action?")) return; await api("/api/governance/kill-switch", { method: "POST", body: { actor: await actor(), on } }); await load(); };
load();
