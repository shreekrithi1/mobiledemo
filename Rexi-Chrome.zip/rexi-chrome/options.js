import { settings } from "./api.js";
const $ = id => document.getElementById(id);
const s = await settings(); $("server").value = s.server; $("name").value = s.name; $("token").value = s.token;
$("save").onclick = async () => {
  const server = $("server").value.trim().replace(/\/$/, "") || "http://localhost:8000";
  if (!/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(server)) {
    const origin = new URL(server).origin + "/*";
    const ok = await chrome.permissions.request({ origins: [origin] });
    if (!ok) { $("msg").textContent = "Permission needed to reach " + origin; return; }
  }
  await chrome.storage.sync.set({ server, name: $("name").value.trim(), token: $("token").value });
  $("msg").textContent = "Saved ✓"; chrome.runtime.sendMessage("refresh");
};
