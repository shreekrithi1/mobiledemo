import { api } from "./api.js";
// Keep the toolbar badge current: fixes waiting for a person, red when any is below the release floor.
async function refreshBadge() {
  try {
    const r = await api("/api/governance/fixes");
    const waiting = r.fixes.filter(f => f.latest && f.latest.status !== "approved");
    const low = waiting.some(f => f.latest.confidence < r.floor);
    await chrome.action.setBadgeText({ text: waiting.length ? String(waiting.length) : "" });
    await chrome.action.setBadgeBackgroundColor({ color: low ? "#dc2626" : "#0f766e" });
    await chrome.action.setTitle({ title: `Rexi · ${waiting.length} fix(es) waiting · average confidence ${r.summary.average_confidence ?? "—"}%` });
  } catch { await chrome.action.setBadgeText({ text: "!" }); await chrome.action.setBadgeBackgroundColor({ color: "#64748b" }); await chrome.action.setTitle({ title: "Rexi · server not reachable" }); }
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("rexi-refresh", { periodInMinutes: 1 });
  chrome.contextMenus.create({ id: "rexi-redact", title: "Rexi: redact personal data (result in the Rexi popup)", contexts: ["selection"] });
  refreshBadge();
});
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.alarms.onAlarm.addListener(a => { if (a.name === "rexi-refresh") refreshBadge(); });
chrome.runtime.onMessage.addListener((m) => { if (m === "refresh") refreshBadge(); });
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "rexi-redact" || !info.selectionText) return;
  try {
    const r = await api("/api/governance/redact", { method: "POST", body: { text: info.selectionText } });
    await chrome.storage.local.set({ lastRedaction: r });
    await chrome.action.setBadgeText({ text: "✓" }); setTimeout(refreshBadge, 2500);
  } catch (e) { await chrome.storage.local.set({ lastRedaction: { error: e.message } }); }
});
