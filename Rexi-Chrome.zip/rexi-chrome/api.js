// Shared Rexi API client for the popup, options page and background worker.
export const DEFAULTS = { server: "http://localhost:8000", name: "", token: "" };
export async function settings() { return { ...DEFAULTS, ...(await chrome.storage.sync.get(Object.keys(DEFAULTS))) }; }
export async function api(path, { method = "GET", body } = {}) {
  const s = await settings();
  const headers = { "Content-Type": "application/json", "Accept": "application/json" };
  if (s.token) headers["X-MobileHeal-Token"] = s.token;
  let r;
  try { r = await fetch(s.server.replace(/\/$/, "") + path, { method, headers, body: body ? JSON.stringify(body) : undefined }); }
  catch (e) { throw new Error(`Can't reach Rexi at ${s.server}. Is it running? Check the server in Options.`); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.detail || `Rexi returned ${r.status}`);
  return data;
}
export async function actor() { const s = await settings(); return s.name || "Chrome user"; }
