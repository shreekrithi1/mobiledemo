# Rexi for Chrome

Autopilot fixes, confidence from all ten agents, reject / rerun / approve, and governance — from your browser toolbar.

## Install (Chrome, Edge, Brave — any Chromium browser)
1. Unzip **Rexi-Chrome.zip**.
2. Open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and pick the `rexi-chrome` folder.
4. Click the Rexi icon → **Settings**: set your Rexi server (default `http://localhost:8000`) and your name.

The extension ID is fixed (`bkhnefejccojbekghloopjbjjpoaamfl`), and the Rexi server trusts it for actions. For a server outside localhost, Chrome asks once for permission to reach it.

## Features
- **Toolbar badge:** fixes waiting for a person — red when any is below the release floor. Refreshes every minute.
- **Fixes:** each fix's confidence ring, all ten agents' scores, Reject with feedback, Rerun, Approve (below the floor asks for a logged override).
- **Trust:** decision-log integrity, floor, routing accuracy, LLM budget, autonomy per use case, and the evidence pack.
- **Redact:** paste text or right-click any selection → "Rexi: redact personal data" to see exactly what a model would see.
- **Pause agents:** the kill switch, one click from any tab.
