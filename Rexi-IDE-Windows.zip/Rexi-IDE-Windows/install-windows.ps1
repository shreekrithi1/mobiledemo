# Rexi for OpenCode — Windows 10/11 installer (run in PowerShell)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $env:USERPROFILE ".config\opencode"
$RexiHome = Join-Path $env:USERPROFILE ".rexi"
Write-Host "▸ Rexi for OpenCode — installing to $Dest"
if (-not (Get-Command opencode -ErrorAction SilentlyContinue)) {
  Write-Host "▸ Installing OpenCode (open source, MIT)…"
  if (Get-Command npm -ErrorAction SilentlyContinue) { npm install -g opencode-ai }
  elseif (Get-Command scoop -ErrorAction SilentlyContinue) { scoop install opencode }
  else { Write-Host "✗ Install Node.js (https://nodejs.org) or Scoop first, then re-run."; exit 1 }
}
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) { $py = Get-Command py -ErrorAction SilentlyContinue }
if (-not $py) { Write-Host "✗ Python 3 is required for the Rexi tools: winget install Python.Python.3.12"; exit 1 }
New-Item -ItemType Directory -Force -Path "$Dest\agents","$Dest\themes",$RexiHome | Out-Null
Copy-Item -Recurse -Force "$Here\mcp" $RexiHome; Copy-Item -Force "$Here\REXI.md" $RexiHome
Copy-Item -Force "$Here\.opencode\agents\*.md" "$Dest\agents"; Copy-Item -Force "$Here\.opencode\themes\rexi.json" "$Dest\themes"
$url = Read-Host "Rexi server URL [http://localhost:8000]"; if (-not $url) { $url = "http://localhost:8000" }
$cfg = Get-Content "$Here\opencode.json" -Raw
$rh = $RexiHome -replace '\\','/'; $dd = $Dest -replace '\\','/'
$cfg = $cfg.Replace('"python3"', '"' + ($py.Source -replace '\\','/') + '"').Replace('{env:REXI_HOME}', $rh).Replace('"REXI.md"', '"' + "$rh/REXI.md" + '"').Replace('http://localhost:8000', $url)
if (Test-Path "$Dest\opencode.json") { Set-Content "$Dest\opencode.json.rexi" $cfg; Write-Host "▸ Kept your opencode.json; Rexi config saved as opencode.json.rexi — merge the mcp/agent/command blocks." }
else { Set-Content "$Dest\opencode.json" $cfg }
if (-not (Test-Path "$Dest\tui.json")) { Copy-Item "$Here\tui.json" "$Dest\tui.json" }
Write-Host "✓ Done. Open a project and run:  opencode   then try  /rexi-fixes"
